# -*- coding: utf-8 -*-
import pygame as pg
import random
import os
import copy
import asyncio
# ================= Inicialização =================
pg.init()
pg.font.init()
pg.mixer.init()

try:
    pg.mixer.music.load('sons/musica_fundo.ogg')
    pg.mixer.music.set_volume(0.3)
    pg.mixer.music.play(-1)
except:
    print("Aviso: Música de fundo não carregada.")


# ================= Classe do jogo =================
class Travessia:
    def __init__(self):
        self.win = pg.display.set_mode((900, 935))
        pg.display.set_caption("Ecological Frog")
        self.fps = pg.time.Clock()
        self.frog_pos = [420, 860]
        self.frog_y = [860, 735, 635, 535, 435, 335, 235, 135, 15]

        self.initial_rows = [
            [0, 150, 250, 600],
            [60, 180, 420, 660],
            [50, 650],
            [50, 250, 450, 800],
            [120, 360, 720],
            [0, 700],
            [100, 250, 450, 700, 800]
        ]
        self.rows = copy.deepcopy(self.initial_rows)
        self.platform_speeds = [1.2, -1.0, 0.9, -1.4, 1.0, -0.8, 1.3]

        frog_img = pg.image.load('images/frog.png')
        bg_img   = pg.image.load('images/background.jpg')
        biel     = pg.image.load('images/plat.jpg')
        trunk    = pg.image.load('images/tronco.png')
        turtle   = pg.image.load('images/turtle.png')

        self.item_timer = pg.time.get_ticks()
        self.lixo_platform = 0
        self.lixo_offset = 0

        self.dragging = False
        self.drag_start = (0, 0)
        

        # Sons
        try:
            self.som_pulo = pg.mixer.Sound('sons/jump.ogg')
            self.som_agua = pg.mixer.Sound('sons/water.ogg')
            self.som_vitoria = pg.mixer.Sound('sons/win.ogg')
            self.som_derrota = pg.mixer.Sound('sons/lose.ogg')
        except:
            class DummySound: 
                def play(self): pass
            self.som_pulo = self.som_agua = self.som_vitoria = self.som_derrota = DummySound()

        self.frog  = pg.transform.scale(frog_img, (60, 60))
        self.bg    = pg.transform.scale(bg_img, (900, 934))
        self.plant = pg.transform.scale(biel, (100, 100))
        self.trunk = pg.transform.scale(trunk, (310, 110))
        self.turt  = pg.transform.scale(turtle, (120, 100))


        self.width_by_row = []
        for i in range(len(self.rows)):
            if i in [0, 3, 6]:
                self.width_by_row.append(self.plant.get_width())
            elif i in [1, 4]:
                self.width_by_row.append(self.turt.get_width())
            else:
                self.width_by_row.append(self.trunk.get_width())

        self.lives = 3
        self.score = 0
        self.level = 1
        self.speed_multiplier = 1.0
        self.start_time = pg.time.get_ticks()
        self.font = pg.font.SysFont('arial', 24, bold=True)
        self.message_timer = 0
        self.message_text = ""
        self.message_color = (255,255,255)
        self.message_duration = 0
        self.jump_count = 0
        # ===== BOTÕES TOUCH =====
        self.btn_size = 90

        self.btn_up = pg.Rect(660, 720, self.btn_size, self.btn_size)
        self.btn_down = pg.Rect(660, 830, self.btn_size, self.btn_size)
        self.btn_left = pg.Rect(550, 830, self.btn_size, self.btn_size)
        self.btn_right = pg.Rect(770, 830, self.btn_size, self.btn_size)
        self.btn_exit = pg.Rect(20, 20, 140, 60)
        self.touch_font = pg.font.SysFont('arial', 50, bold=True)
        # lixo atual
        self.lixo_tipo = None
        self.lixo_pos = [0, 0]
        self.lixo_active = False
        self.lixo_carregado = False

        self.lixo_row = 0
        self.lixo_platform = 0
        self.lixo_offset = 0
        self.item_timer = pg.time.get_ticks()
        # Animação de água
        self.water_frames = [pg.transform.scale(pg.image.load(f'animacoes/aguas/agua{i}.png'), (80,80)) for i in range(1,5)]

        # ===== LIXOS =====
        self.lixos = {
            "plastico": pg.transform.scale(
                pg.image.load('garbage/lixo1.png'), (50, 50)
            ),

            "papel": pg.transform.scale(
                pg.image.load('garbage/lixo2.png'), (50, 50)
            ),

            "metal": pg.transform.scale(
                pg.image.load('garbage/lixo3.png'), (50, 50)
            ),

            "vidro": pg.transform.scale(
                pg.image.load('garbage/lixo4.png'), (50, 50)
            )
        }


        # ===== CAIXOTES =====
        self.caixotes = [
            {
                "tipo": "plastico",
                "x": 80,
                "y": 0,
                "img": pg.transform.scale(
                    pg.image.load('garbage/clixo1.png'), #plastico
                    (80,80)
                )
            },

            {
                "tipo": "metal",
                "x": 280,
                "y": 0,
                "img": pg.transform.scale(
                    pg.image.load('garbage/clixo2.png'), #metal
                    (80,80)
                )
            },

            {
                "tipo": "papel",
                "x": 500,
                "y": 0,
                "img": pg.transform.scale(
                    pg.image.load('garbage/clixo3.png'), #papel
                    (80,80)
                )
            },

            {
                "tipo": "vidro",
                "x": 700,
                "y": 0,
                "img": pg.transform.scale(
                    pg.image.load('garbage/clixo4.png'), #vidro
                    (80,80)
                )
            }
        ]
        # Inimigos
        self.enemies = [
            [random.randint(0, 800), 735, -1],
            [random.randint(0, 800), 435, 1],
            [random.randint(0, 800), 135, -1]
        ]
        self.enemy_frames = [
            pg.transform.scale(pg.image.load(f'animacoes/enemys/enemy{i}.png'), (85, 85))
            for i in range(1, 5)
        ]
        self.enemy_frame_index = 0
        self.enemy_frame_delay = 5
        self.enemy_tick = 0

    # ======= Desenho e HUD =======
    def clear(self):
        self.win.blit(self.bg, (0, 0))

    def draw_platforms(self):
        for y, row in enumerate(self.rows):
            y_pos = [715, 615, 515, 415, 315, 215, 115][y]
            for x in row:
                if y in [0, 3, 6]:
                    self.win.blit(self.plant, (x, y_pos))
                elif y in [1, 4]:

                    # virar tartaruga conforme direção
                    if self.platform_speeds[y] < 0:

                        turtle_img = pg.transform.flip(
                            self.turt,
                            True,
                            False
                        )

                    else:
                        turtle_img = self.turt

                    self.win.blit(turtle_img, (x, y_pos))
                elif y in [2, 5]:
                    self.win.blit(self.trunk, (x, y_pos))

    def draw_caixotes(self):
        for c in self.caixotes:
            self.win.blit(c["img"], (c["x"], c["y"]))

    def draw_frog(self):
        self.win.blit(self.frog, (self.frog_pos[0], self.frog_pos[1]))
    
    def draw_item(self):

        if self.lixo_active and not self.lixo_carregado:

            img = self.lixos[self.lixo_tipo]

            self.win.blit(img, self.lixo_pos)

        # lixo sendo carregado pelo sapo
        if self.lixo_carregado:

            img = self.lixos[self.lixo_tipo]

            self.win.blit(
                img,
                (self.frog_pos[0] + 5, self.frog_pos[1] - 20)
            )
    

    def draw_enemies(self):
        frame = self.enemy_frames[self.enemy_frame_index]
        for x, y, dir in self.enemies:
            img = pg.transform.flip(frame, True, False) if dir < 0 else frame
            self.win.blit(img, (x, y))

    def show_message(self, text, color=(255,255,255), duration=2000):

        self.message_text = text
        self.message_color = color

        self.message_timer = pg.time.get_ticks()
        self.message_duration = duration

    def draw_message(self):

        now = pg.time.get_ticks()

        if now - self.message_timer < self.message_duration:

            font = pg.font.SysFont('arial', 50, bold=True)

            text = font.render(
                self.message_text,
                True,
                self.message_color
            )

            rect = text.get_rect(center=(450, 470))

            # fundo transparente
            bg = pg.Surface((rect.width + 40, rect.height + 20))

            bg.set_alpha(180)

            bg.fill((0,0,0))

            self.win.blit(
                bg,
                (rect.x - 20, rect.y - 10)
            )

            self.win.blit(text, rect)
    def draw_hud(self):

        # ===== FUNDO HUD =====
        hud_surface = pg.Surface((900, 70))
        hud_surface.set_alpha(140)
        hud_surface.fill((0, 0, 0))

        self.win.blit(hud_surface, (0, 910))

        # ===== BARRA DE VIDA =====

        max_lives = 3

        bar_x = 20
        bar_y = 20

        bar_width = 200
        bar_height = 18

        # fundo vermelho
        pg.draw.rect(
            self.win,
            (120, 0, 0),
            (bar_x, bar_y + 895, bar_width, bar_height),
            border_radius=20
        )

        # vida atual verde
        current_width = (self.lives / max_lives) * bar_width

        pg.draw.rect(
            self.win,
            (0, 220, 0),
            (bar_x, bar_y + 895, current_width, bar_height),
            border_radius=20
        )

        # borda branca
        pg.draw.rect(
            self.win,
            (255,255,255),
            (bar_x, bar_y + 895, bar_width, bar_height),
            3,
            border_radius=20
        )

       
        # ===== SCORE =====

        score_txt = self.font.render(
            f"SCORE: {self.score}",
            True,
            (255,255,0)
        )

        self.win.blit(score_txt, (300, 910))

        # ===== PULOS =====

        jump_txt = self.font.render(
            f"PULOS: {self.jump_count}",
            True,
            (255,120,255)
        )

        self.win.blit(jump_txt, (520, 910))

        # ===== NIVEL =====

        level_txt = self.font.render(
            f"NIVEL: {self.level}",
            True,
            (0,255,255)
        )

        self.win.blit(level_txt, (760, 910))

        # ===== LIXO CARREGADO =====
    
        

    def reset_frog(self):

        self.frog_pos = [420, 860]

        # perder lixo ao morrer
        self.lixo_carregado = False

    # ======= Movimento =======
    def move(self, key):
        # encontrar índice da linha mais próxima
        frog_y = self.frog_pos[1]
        closest_idx = min(range(len(self.frog_y)), key=lambda i: abs(self.frog_y[i] - frog_y))
        # Descobre qual "linha" vertical o sapo está mais próximo.
        # Assim, o sapo se move entre faixas fixas, não livremente.
        
        if key in ['w','up']:
            self.frog_pos[1] = self.frog_y[min(closest_idx+1, len(self.frog_y)-1)]
            self.jump_count +=1; self.som_pulo.play()
        elif key in ['s','down']:
            self.frog_pos[1] = self.frog_y[max(closest_idx-1,0)]
            self.jump_count +=1; self.som_pulo.play()
        elif key in ['a','left'] and self.frog_pos[0]>0:
            self.frog_pos[0]-=50; self.jump_count+=1; self.som_pulo.play()
        elif key in ['d','right'] and self.frog_pos[0]<840:
            self.frog_pos[0]+=50; self.jump_count+=1; self.som_pulo.play()
        # O sapo se move em passos de 50 pixels por tecla pressionada.
    async def animar_agua(self):
        for frame in self.water_frames:
            self.clear()
            self.update_platforms()
            self.draw_platforms()
            self.draw_enemies()
            self.draw_hud()
            self.win.blit(frame, (self.frog_pos[0]-10, self.frog_pos[1]-10))
            pg.display.update()
            await asyncio.sleep(0.08)

    def spawn_item(self):

        tipos = ["plastico", "papel", "metal", "vidro"]

        self.lixo_tipo = random.choice(tipos)

        # escolhe linha
        row_idx = random.randint(0, 6)

        row = self.rows[row_idx]

        # escolhe plataforma específica
        plat_index = random.randint(0, len(row)-1)

        plataforma_x = row[plat_index]

        y_positions = [715, 615, 515, 415, 315, 215, 115]

        lixo_y = y_positions[row_idx]

        largura = self.width_by_row[row_idx]

        # salvar referência
        self.lixo_row = row_idx
        self.lixo_platform = plat_index

        # offset dentro da plataforma
        self.lixo_offset = largura//2 - 25

        self.lixo_pos = [
            plataforma_x + self.lixo_offset,
            lixo_y + 20
        ]

        self.lixo_active = True
        self.lixo_carregado = False

    def update_item(self):

        now = pg.time.get_ticks()

        # ===== SPAWN =====
        if not self.lixo_active and now - self.item_timer > 5000:

            self.spawn_item()
            self.item_timer = now

        # ===== MOVIMENTO DO LIXO =====

        if self.lixo_active and not self.lixo_carregado:

            lixo_y = self.lixo_pos[1]
        
        plataforma_x = self.rows[self.lixo_row][self.lixo_platform]

        self.lixo_pos[0] = (
            plataforma_x + self.lixo_offset
        )
                    
            

        # ===== PEGAR LIXO =====

        if self.lixo_active and not self.lixo_carregado:

            frog_rect = pg.Rect(
                self.frog_pos[0],
                self.frog_pos[1],
                60,
                60
            )

            lixo_rect = pg.Rect(
                self.lixo_pos[0],
                self.lixo_pos[1],
                50,
                50
            )

            if frog_rect.colliderect(lixo_rect):

                self.lixo_carregado = True
                self.show_message(
                f"{self.lixo_tipo.upper()} COLETADO",
                (0,255,100)
                )

        # ===== ENTREGAR =====

        if self.lixo_carregado:

            frog_rect = pg.Rect(
                self.frog_pos[0],
                self.frog_pos[1],
                60,
                60
            )

            for c in self.caixotes:

                bin_rect = pg.Rect(
                    c["x"],
                    c["y"],
                    80,
                    80
                )

                if frog_rect.colliderect(bin_rect):

                    # acertou
                    if c["tipo"] == self.lixo_tipo:

                        self.score += 100
                        self.show_message(
                        "+100 RECICLAGEM CORRETA",
                        (0,255,0)
                        )

                    else:

                        self.score -= 50
                        self.show_message(
                        "CAIXOTE ERRADO -50",
                        (255,50,50)
                        )

                    # reset lixo
                    self.lixo_active = False
                    self.lixo_carregado = False
                    self.lixo_tipo = None

                    break
                    
           

    # ======= Atualizações =======
    def update_enemies(self):
        for i, (x, y, dir) in enumerate(self.enemies):
            x += dir * 3 * self.speed_multiplier
            if x>900: x=-60
            if x<-60: x=900
            self.enemies[i][0]=x
        self.enemy_tick+=1
        if self.enemy_tick>=self.enemy_frame_delay:
            self.enemy_frame_index=(self.enemy_frame_index+1)%len(self.enemy_frames)
            self.enemy_tick=0


    def update_platforms(self):
        screen_w = self.win.get_width()
        for row_idx, row in enumerate(self.rows):
            speed = self.platform_speeds[row_idx] * self.speed_multiplier
            width = self.width_by_row[row_idx]
            for i in range(len(row)):
                x = row[i] + speed
                if x > screen_w: x = -width
                elif x < -width: x = screen_w
                row[i] = x

    # ======= Colisões =======
    def check_enemy_collision(self):
        frog_rect=pg.Rect(self.frog_pos[0],self.frog_pos[1],60,60)
        for ex,ey,_ in self.enemies:
            enemy_rect=pg.Rect(ex,ey,60,60)
            if frog_rect.colliderect(enemy_rect):
                self.reset_frog(); self.lives-=1
                self.som_derrota.play(); return True
        return False

    def check_win(self):
        """
        Verifica se o sapo alcançou a linha de chegada (topo do rio).
        Funciona mesmo que o Y do sapo não seja exatamente 15.
        """
        topo = 15  # Posição aproximada da linha de chegada
        tolerancia = 10  # Permite uma faixa de 10 pixels
        return abs(self.frog_pos[1] - topo) <= tolerancia

    async def check_platforms_and_water(self):
        """
        Verifica se o sapo está sobre uma plataforma ou caiu na água.
        Move o sapo junto com a plataforma quando necessário.
        Funciona para qualquer largura de plataforma e múltiplas plataformas por linha.
        """
        frog_rect = pg.Rect(self.frog_pos[0], self.frog_pos[1], 60, 60)

        # Altura de cada plataforma e posição vertical da linha
        alturas = [100, 100, 110, 100, 100, 110, 100]  
        y_positions = [715, 615, 515, 415, 315, 215, 115]  

        # Apenas linhas que são água real (tartarugas em movimento, sem tronco)
        water_rows = {1, 4}

        on_platform = False

        # Verifica cada linha
        for row_idx, row in enumerate(self.rows):
            largura = self.width_by_row[row_idx]
            altura = alturas[row_idx]
            y_pos = y_positions[row_idx]

            # Linha na mesma faixa vertical do sapo
            if frog_rect.bottom > y_pos and frog_rect.top < y_pos + altura:
                for x in row:
                    plat_rect = pg.Rect(x, y_pos, largura, altura)
                    if frog_rect.colliderect(plat_rect):
                        on_platform = True
                        move_x = self.platform_speeds[row_idx] * self.speed_multiplier

                        # Ajusta verticalmente se estiver sobre linha de água (tartaruga)
                        if row_idx in water_rows:
                            self.frog_pos[1] = y_pos + altura - 60

                        # Movimenta o sapo junto com a plataforma
                        new_x = self.frog_pos[0] + move_x
                        left_limit = x
                        right_limit = x + largura - 60  # largura do sapo

                        if new_x < left_limit:
                            self.frog_pos[0] = left_limit
                        elif new_x > right_limit:
                            self.frog_pos[0] = right_limit
                        else:
                            self.frog_pos[0] = new_x

                        break 
                break  

        # Se não está sobre plataforma e está em linha de água
        if not on_platform and self.frog_pos[1] in self.frog_y[1:7]:
            self.som_agua.play()
            self.lives -= 1
            await self.animar_agua()
            self.reset_frog()




async def tela_inicial(jogo):

    font_title = pg.font.SysFont('arial', 70)
    button_font = pg.font.SysFont('arial', 60)

    button_iniciar_text = button_font.render(
        "INICIAR",
        True,
        (255, 255, 255)
    )

    button_iniciar_rect = button_iniciar_text.get_rect(
        center=(450, 800)
    )

    btn_sair = pg.Rect(685, 10, 200, 70)

    waiting = True

    while waiting:

        jogo.win.fill((0, 0, 30))

        # ===== TÍTULO =====
        title = font_title.render(
            "Ecological Frog",
            True,
            (0, 255, 0)
        )

        jogo.win.blit(title, (200, 300))

        # ===== MOUSE =====
        mouse_pos = pg.mouse.get_pos()

        # ===== BOTÃO INICIAR =====
        if button_iniciar_rect.collidepoint(mouse_pos):

            pg.draw.rect(
                jogo.win,
                (0, 200, 0),
                button_iniciar_rect.inflate(40, 20),
                border_radius=15
            )
        else:
            pg.draw.rect(
                jogo.win,
                (0, 128, 0),
                button_iniciar_rect.inflate(40, 20),
                border_radius=15
            )

        jogo.win.blit(button_iniciar_text, button_iniciar_rect)

        # ===== BOTÃO SAIR =====
        pg.draw.rect(
            jogo.win,
            (200, 50, 50),
            btn_sair,
            border_radius=15
        )

        sair_text = button_font.render(
            "SAIR",
            True,
            (255, 255, 255)
        )

        jogo.win.blit(
            sair_text,
            sair_text.get_rect(center=btn_sair.center)
        )

        # ===== EVENTOS =====
        for event in pg.event.get():

            if event.type == pg.QUIT:
                pg.quit()
                return None

            elif event.type == pg.MOUSEBUTTONDOWN:

                # SAIR
                if btn_sair.collidepoint(event.pos):
                    pg.quit()
                    return None

                # INICIAR
                if button_iniciar_rect.collidepoint(event.pos):
                    return True

        pg.display.update()
        await asyncio.sleep(0)


import asyncio

async def main():

    jogo = Travessia()

    while True:

        res = await tela_inicial(jogo)

        if res is None:
            return

        jogo.lives = 3
        jogo.score = 0
        jogo.level = 1
        jogo.speed_multiplier = 1.0
        jogo.jump_count = 0
        

        jogo.start_time = pg.time.get_ticks()

        jogo.frog_pos = [420,860]

        jogo.rows = copy.deepcopy(
            jogo.initial_rows
        )

        running = True

        while running:

            jogo.fps.tick(90)

            for event in pg.event.get():

                if event.type == pg.QUIT:
                    running = False

                elif event.type == pg.KEYDOWN:

                    key_name = pg.key.name(event.key)
                    jogo.move(key_name)

                    if key_name == 'escape':
                        running = False

                elif event.type == pg.MOUSEBUTTONDOWN:

                    jogo.dragging = True
                    jogo.drag_start = event.pos

                    # botão sair ainda funciona aqui
                    mx, my = event.pos

                    if jogo.btn_exit.collidepoint(mx, my):
                        pg.quit()
                        return

                elif event.type == pg.MOUSEBUTTONUP:

                    jogo.dragging = False

                elif event.type == pg.MOUSEMOTION and jogo.dragging:
                    mx, my = event.pos

                    sx, sy = jogo.drag_start
                    dx = mx - sx
                    dy = my - sy

                    if abs(dx) > 80 or abs(dy) > 80:

                        if abs(dx) > abs(dy):

                            if dx > 0:
                                jogo.move('right')
                            else:
                                jogo.move('left')

                        else:

                            if dy > 0:
                                jogo.move('down')
                            else:
                                jogo.move('up')

                        jogo.drag_start = (mx, my)

            jogo.clear()

            jogo.update_enemies()

            jogo.update_platforms()

            jogo.update_item()

            await jogo.check_platforms_and_water()

            jogo.draw_platforms()

            jogo.draw_caixotes()

            jogo.draw_frog()

            jogo.draw_item()

            jogo.draw_enemies()

            jogo.draw_hud()

            jogo.draw_message()

           

            jogo.check_enemy_collision()

            if jogo.check_win() and not jogo.lixo_carregado:

                jogo.som_vitoria.play()

                tempo = (
                    pg.time.get_ticks()
                    - jogo.start_time
                ) // 1000

                pontos = max(100-tempo,10)

                jogo.score += pontos

                jogo.level += 1

                jogo.speed_multiplier += 0.05

                jogo.jump_count = 0

                jogo.reset_frog()

            if jogo.lives <= 0:

                jogo.win.fill((0,0,0))

                font = pg.font.SysFont(
                    'arial',
                    80
                )

                gameover = font.render(
                    'GAME OVER',
                    True,
                    (255,0,0)
                )

                jogo.win.blit(
                    gameover,
                    (250,400)
                )

                pg.display.update()

                await asyncio.sleep(2)

                running = False

            pg.display.update()

            await asyncio.sleep(0)

if __name__ == '__main__':
    asyncio.run(main())